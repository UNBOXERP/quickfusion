# CHANGELOG IMPORTORDERLINES FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
## 1.1

programacion de multiprecio

## 1.2

changes en upload error en sql cuando no hay datos
## 1.3

ordenamineto en upload y link de archivo
