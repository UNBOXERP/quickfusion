INSERT INTO llxas_const (name,entity,value,`type`,visible,note,tms) VALUES
	 ('multiprecio_ORDEN5',1,'5','chaine',0,'','2023-05-19 15:05:14'),
	 ('multiprecio_ORDEN4',1,'4','chaine',0,'','2023-05-19 15:05:14'),
	 ('multiprecio_ORDEN3',1,'3','chaine',0,'','2023-05-19 15:05:14'),
	 ('multiprecio_ORDEN2',1,'2','chaine',0,'','2023-05-19 15:05:14'),
	 ('multiprecio_ORDEN1',1,'1','chaine',0,'','2023-05-19 15:05:14');

INSERT INTO llxas_const (name,entity,value,`type`,visible,note,tms) VALUES
('multiprecio_ORDEN6',1,'6','chaine',0,'','2023-05-19 15:05:14');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_1','2022 270');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_2','List 269');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_3','Adrenaline 270');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_4','CFS 269');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_5','Bulk 270');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','Selling_price_6','price6_new');

INSERT INTO llxas_overwrite_trans (entity,lang,transkey,transvalue) VALUES
		 (1,'en_US','ParametersMultiprice','Parameters Multiprice');
