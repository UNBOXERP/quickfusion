# CHANGELOG MULTIPRECIOS FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.0

Initial version
funciona con validate


## 1.1

cambios para verificar precios desde js

## 1.2

cambnios en labels tanto en card product asi como price  copiando cards
